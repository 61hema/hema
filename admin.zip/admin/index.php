<?php

include("config/database.php");
session_start();

extract($_POST);

if(isset($login))
{
	$sel = mysqli_query($con,"select * from admin where email='$em'");
	$arr = mysqli_fetch_assoc($sel);
	if($arr['email']==$em && $arr['password']==md5($pass))
	{
		$_SESSION['ademail']=$em;
		header("location:dashboard.php");
	}
	else
	{
		$msg="Invalid Login";
	}
}
?>

<html>
    <head>
        <title>admin login</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <style>
              body
              {
                    background:url("images/learn.jpg");
                    background-size:cover;
                    background-position:top;
              }
              .jumbotron
                {
                    color:white;
                    background: rgba(0 ,0, 0, .6);
                    border-radius:30px;
                   margin:20px;
                }
                label 
                 {
                    color:white;
                    font-size:20px; 
                 }
                .eyediv
                {
                    position:relative;
                }
                #eye
                {
                    position:absolute; 
                    top:61.5%;
                    right:2%;
                    color:blue;
                }
        </style>
        <script src="js/bootstrap.min.js" type="text/javascript"  ></script>
        <script>
		function eyecode()
		{
			 if(document.getElementById("pass").type=="password")
			 {
				 document.getElementById("pass").type="text";
				 document.getElementById("eye").className="glyphicon glyphicon-eye-open";
			 }
			 else
			 {
				 document.getElementById("pass").type="password";
				 document.getElementById("eye").className="glyphicon glyphicon-eye-close";
			 }	 			 
		}
	</script>
    </head>   
    <body>
       <main>
            <header class="jumbotron" >
            <h1 class="text-center">ADMIN PANEL</h1></header>
            <form method="post">
            <section class="container">
            <?php
				if(!empty($msg))
		
				{
				?>
				<label class="alert-danger"><?=$msg?></label>
				<?php
				}
				?>
                <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="em" class="form-control" required>
                </div>
                <div class="form-group eyediv">
                        <label>Password</label>
                        <input type="password" name="pass" id="pass" class="form-control" required>
                        <span id="eye" class="glyphicon glyphicon-eye-close" onclick="eyecode()"></span>
                </div>
                <div class="form-group">
                        <input type="submit" name="login" value="Login" class="btn btn-primary btn-lg">
				</div>
			</section>
         </main>
    </body>
</html>
