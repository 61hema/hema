<?php
$con=mysqli_connect("localhost","root","","project");
extract($_POST);
if(isset($sub))
{
	if(mysqli_query($con,"insert into department(deptname,deptcode,depthod) values('$deptname','$deptcode','$hod')"))
	{
		header("location:department.php");
	}
	
}
?>
?>
<html>
<head>
	<title>
		Add Department
	</title>
	<script src="js/bootsrap.min.js" ></script>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="adddept.css" rel="stylesheet">
	</head>
	<body>
		  <main>
    		
    		<header>
				<?php include("navbar.php") ?>
			</header>
			
			<div>
				<aside class="col-sm-2">
				    <?php include("sidebar.php"); ?>
				</aside>
				
				<section class="col-sm-10">
				<h2>ADD  DEPARTMENT</h2>
                   <div class="container">
                   <form method="" ="post">
						  <div class="form-group">
						    <label for="Department Name">Department Name</label>
						    <input type="text" class="form-control" id="deptname" name="deptname">
						  </div>
						  <div class="form-group">
						    <label for="Department Code">Department Code</label>
						    <input type="text" class="form-control" id="deptcode"  name="deptcode">
						  </div>
						  <div class="form-group">
						    <label for="HOD">Head Of Department</label>
						    <input type="text" class="form-control" id="hod"  name="hod">
						  </div>
						  <button type="submit" class="btn btn-success">Submit</button>
						</form>

				</div>
                </section>
                </div>
            </main>
	</body>
</html>