<style>
	.sidenav {
  height: 90%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top:10px;
  display:inline-block;
  margin-top: 4%;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}
</style>
<div class="sidenav">
			  <a href="#about">About</a>
			  <a href="#services">Services</a>
			  <a href="department.php">Department</a>
			  <a href="#contact">Contact</a>
		</div>