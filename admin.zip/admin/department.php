<html>
<head>
	<title>
		Department
	</title>
	<script src="js/bootsrap.min.js" ></script>
        <link href="css/bootstrap.min.css" rel="stylesheet">
	</head>
	<body>
		  <main>
    		
    		<header>
				<?php include("navbar.php") ?>
			</header>
			
			<div>
				<aside class="col-sm-2">
				    <?php include("sidebar.php"); ?>
				</aside>
				
				<section class="col-sm-10">
				<h2>Department</h2>
                   <table class="table">
                   	<tr>
                   		<td><a href="adddept.php"><input type="button" name="adddept" value="Add Department"></a></td>
                   	</tr>
                   </table>   
				</div>
                </section>
                </div>
            </main>
	</body>
</html>